'use strict';

const React = require('react');

const ResumePropTypes = require('../../prop_types/resume');
const SocialMedia = require('../social_media');

const Footer = React.createClass({
    propTypes: {
        content: ResumePropTypes.basics
    },

    render: function () {
        return (
            <footer>
                <div className='row'>
                    <div className='twelve columns'>
                        <SocialMedia ulClass='social-links' profiles={this.props.content.profiles}/>
                        <ul className='copyright'>
                            <li>
                                This site uses React.js for&nbsp;
                                <a
                                    href='https://otiz.github.io'
                                    title='Otis White'
                                    target='_blank'
                                    rel='noopener noreferrer'>
                                    Otis White
                                </a> and hosted on&nbsp;
                                <a
                                    href='https://github.com/OTiZ/otiz.github.io'
                                    title='Github'
                                    target='_blank'
                                    rel='noopener noreferrer'>
                                    Github
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div id='go-top'>
                        <a className='smoothscroll' title='Back to Top' href='#home'>
                            <i className='icon-up-open'/>
                        </a>
                    </div>
                </div>
            </footer>
        );
    }
});

module.exports = Footer;

'use strict';

const React = require('react');

const Loading = React.createClass({
    render: function () {
        return (
            <div className='loading'/>
        );
    }
});

module.exports = Loading;
